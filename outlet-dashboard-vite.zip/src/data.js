// DATA LOADING: the only place data comes from. Reads the outlet_weekly table
// from Supabase through its REST API. If Supabase isn't configured, fails, or
// the table is empty, it falls back to the sample CSV so the dashboard still renders.
// Resolves to { rows: [{ outlet, week, sales, target, orders, returns }], source }.

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
// Publishable key, safe in the browser. Send it on the apikey header only:
// Supabase rejects sb_ keys in Authorization: Bearer.
const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
const SUPABASE_TABLE = 'outlet_weekly';

const CSV = `outlet,week,sales,target,orders,returns
Tampines,2026-09-07,18400,18000,612,9
Tampines,2026-09-14,16100,18000,540,14
Tampines,2026-09-21,19200,18000,640,8
Jurong,2026-09-07,14200,15000,488,11
Jurong,2026-09-14,12600,15000,430,19
Jurong,2026-09-21,15300,15000,512,10
Orchard,2026-09-07,22500,24000,690,12
Orchard,2026-09-14,20100,24000,612,21
Orchard,2026-09-21,24800,24000,742,9`;

const toRow = r => ({
  outlet: r.outlet, week: String(r.week).slice(0, 10),
  sales: +r.sales, target: +r.target, orders: +r.orders, returns: +r.returns,
});

function parseCsv(text) {
  const [head, ...lines] = text.trim().split(/\r?\n/);
  const cols = head.split(',');
  return lines.map(line => {
    const v = line.split(',');
    return toRow(Object.fromEntries(cols.map((c, i) => [c, v[i]])));
  });
}

export async function loadData() {
  try {
    if (!SUPABASE_URL || !SUPABASE_KEY) throw new Error('Supabase env vars not set');
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/${SUPABASE_TABLE}?select=outlet,week,sales,target,orders,returns&order=week`,
      { headers: { apikey: SUPABASE_KEY } });
    if (!res.ok) throw new Error(`Supabase ${res.status}`);
    const data = await res.json();
    if (!data.length) throw new Error('Supabase table is empty');
    return { rows: data.map(toRow), source: 'Supabase' };
  } catch (err) {
    console.warn('Using sample CSV:', err.message);
    return { rows: parseCsv(CSV), source: 'sample CSV' };
  }
}
