import './style.css';
import { loadData } from './data.js';

const OUTLETS = ['All', 'Tampines', 'Jurong', 'Orchard'];
const THRESHOLD = 0.9;
const state = { rows: [], outlet: 'All', source: '' };

const fmtMoney = n => '$' + Math.round(n).toLocaleString('en-SG');
const fmtInt = n => n.toLocaleString('en-SG');
const fmtPct = (n, d = 1) => (n * 100).toFixed(d) + '%';
const fmtWeek = w => new Date(w + 'T00:00:00').toLocaleDateString('en-SG', { day: 'numeric', month: 'short' });
const $ = id => document.getElementById(id);

function render() {
  const rows = state.outlet === 'All' ? state.rows : state.rows.filter(r => r.outlet === state.outlet);
  const sum = k => rows.reduce((a, r) => a + r[k], 0);
  const sales = sum('sales'), target = sum('target'), orders = sum('orders'), returns = sum('returns');

  // Filter buttons
  document.querySelectorAll('#filter button').forEach(b => {
    const on = b.dataset.outlet === state.outlet;
    b.classList.toggle('active', on);
    b.setAttribute('aria-pressed', on);
  });

  // Period subtitle
  const weeks = [...new Set(rows.map(r => r.week))].sort();
  $('period').textContent = weeks.length
    ? `Weeks of ${fmtWeek(weeks[0])} – ${fmtWeek(weeks[weeks.length - 1])} · ${state.outlet === 'All' ? 'All outlets' : state.outlet} · Data: ${state.source}`
    : 'No data';

  // KPIs
  $('kpi-sales').textContent = fmtMoney(sales);
  $('kpi-sales-note').textContent = `Target ${fmtMoney(target)}`;
  $('kpi-pct').textContent = target ? fmtPct(sales / target) : '–';
  $('kpi-pct-note').textContent = sales >= target ? `${fmtMoney(sales - target)} above target` : `${fmtMoney(target - sales)} short of target`;
  $('kpi-orders').textContent = fmtInt(orders);
  $('kpi-orders-note').textContent = orders ? `Avg order ${fmtMoney(sales / orders)}` : '';
  $('kpi-returns').textContent = orders ? fmtPct(returns / orders, 2) : '–';
  $('kpi-returns-note').textContent = `${fmtInt(returns)} returns`;

  // Bars: scale so 100% target sits at a fixed point with headroom
  const ratios = rows.map(r => r.sales / r.target);
  const max = Math.max(1.1, ...ratios);
  const pos = x => (x / max * 100) + '%';
  const sorted = [...rows].sort((a, b) => a.outlet.localeCompare(b.outlet) || a.week.localeCompare(b.week));
  $('bars').innerHTML = sorted.map(r => {
    const p = r.sales / r.target, low = p < THRESHOLD;
    return `<div class="row" title="${r.outlet}, week of ${r.week}: ${fmtMoney(r.sales)} of ${fmtMoney(r.target)}">
      <div class="name">${r.outlet} <span>· ${fmtWeek(r.week)}</span></div>
      <div class="track">
        <div class="fill${low ? ' low' : ''}" style="width:${pos(p)}"></div>
        <div class="mark" style="left:${pos(THRESHOLD)}"></div>
        <div class="mark target" style="left:${pos(1)}"></div>
      </div>
      <div class="pct${low ? ' low' : ''}">${fmtPct(p)}</div>
    </div>`;
  }).join('');

  // Needs attention
  const flagged = sorted.filter(r => r.sales / r.target < THRESHOLD)
    .sort((a, b) => a.sales / a.target - b.sales / b.target);
  $('alert-count').textContent = `${flagged.length} under 90%`;
  $('alerts').innerHTML = flagged.length
    ? flagged.map(r => `<li>
        <div><div class="what">${r.outlet} · week of ${fmtWeek(r.week)}</div>
        <div class="detail">${fmtMoney(r.sales)} of ${fmtMoney(r.target)} · ${fmtPct(r.returns / r.orders, 1)} returns</div></div>
        <div class="gap">${fmtPct(r.sales / r.target)}</div>
      </li>`).join('')
    : '<li class="empty" style="background:none;padding:0">Every outlet-week is at or above 90% of target.</li>';
}

async function init() {
  $('filter').innerHTML = OUTLETS.map(o => `<button type="button" data-outlet="${o}">${o}</button>`).join('');
  $('filter').addEventListener('click', e => {
    const b = e.target.closest('button');
    if (b) { state.outlet = b.dataset.outlet; render(); }
  });
  try {
    ({ rows: state.rows, source: state.source } = await loadData());
  } catch (err) {
    $('period').textContent = 'Could not load data: ' + err.message;
    return;
  }
  render();
}
init();
